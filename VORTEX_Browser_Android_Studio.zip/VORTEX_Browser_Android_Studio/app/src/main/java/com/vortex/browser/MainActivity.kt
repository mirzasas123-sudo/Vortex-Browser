package com.vortex.browser

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var webHolder: FrameLayout
    private lateinit var tabBar: LinearLayout
    private lateinit var aiPanel: LinearLayout
    private lateinit var aiInput: EditText
    private val pages = mutableListOf<WebView>()
    private var current = 0
    private var showingAI = false

    private val bg = Color.rgb(10, 15, 30)
    private val panel = Color.rgb(21, 30, 52)
    private val accent = Color.rgb(70, 150, 255)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
        addTab("https://duckduckgo.com")
    }

    private fun buildUI() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(10, 12, 10, 8)
        }
        val brand = TextView(this).apply {
            text = "VORTEX  /  BROWSER ULTRA"
            setTextColor(white); textSize = 18f
            setPadding(5, 8, 5, 12)
        }
        root.addView(brand)

        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply {
            hint = "Adres veya ara..."
            singleLine = true
            setTextColor(white); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(panel)
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(14, 4, 14, 4)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); true } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        addressRow.addView(makeButton("Git") { navigate(address.text.toString()) })
        root.addView(addressRow)

        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(tabBar)

        webHolder = FrameLayout(this)
        root.addView(webHolder, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        aiPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
            setBackgroundColor(panel)
            visibility = View.GONE
        }
        val aiTitle = TextView(this).apply {
            text = "VORTEX AI  •  Yerel asistan alanı"
            setTextColor(white); textSize = 17f
        }
        val aiInfo = TextView(this).apply {
            text = "Bu sürümde gerçek dil modeli henüz bağlı değil. API'siz gerçek sohbet için ayrıca cihazda çalışacak bir model dosyası ve yerel çıkarım motoru eklenmelidir."
            setTextColor(Color.LTGRAY); textSize = 13f
            setPadding(0, 8, 0, 8)
        }
        aiPanel.addView(aiTitle); aiPanel.addView(aiInfo)
        val chatScroll = ScrollView(this)
        val chatText = TextView(this).apply {
            tag = "chat"
            text = "VORTEX: Merhaba! Yerel model bağlandığında burada sohbet edebileceksin."
            setTextColor(white); textSize = 15f
        }
        chatScroll.addView(chatText)
        aiPanel.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val aiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        aiInput = EditText(this).apply {
            hint = "VORTEX'e sor..."
            setTextColor(white); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(bg)
        }
        aiRow.addView(aiInput, LinearLayout.LayoutParams(0, 48, 1f))
        aiRow.addView(makeButton("Gönder") {
            val q = aiInput.text.toString().trim()
            if (q.isNotEmpty()) {
                chatText.append("\n\nSen: $q\nVORTEX: Bu proje sürümünde yerel yapay zekâ modeli henüz etkin değil. Model entegrasyonu tamamlandığında sorunu yanıtlayacağım.")
                aiInput.setText("")
            }
        })
        aiPanel.addView(aiRow)
        root.addView(aiPanel, LinearLayout.LayoutParams(-1, 230))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(makeButton("‹") { if (pages.isNotEmpty()) pages[current].goBack() })
        controls.addView(makeButton("›") { if (pages.isNotEmpty()) pages[current].goForward() })
        controls.addView(makeButton("+") { addTab("https://duckduckgo.com") })
        controls.addView(makeButton("AI") { toggleAI() })
        controls.addView(makeButton("Sekmeler") { showTabs() })
        root.addView(controls)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(white)
            setBackgroundColor(accent)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun addTab(url: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                if (pages.getOrNull(current) === view && url != null) address.setText(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = false
        }
        pages.add(web)
        current = pages.lastIndex
        webHolder.addView(web, FrameLayout.LayoutParams(-1, -1))
        webHolder.visibility = View.VISIBLE
        pages.forEachIndexed { i, w -> w.visibility = if (i == current) View.VISIBLE else View.GONE }
        address.setText(url)
        web.loadUrl(url)
        refreshTabs()
        showingAI = false
        aiPanel.visibility = View.GONE
    }

    private fun refreshTabs() {
        tabBar.removeAllViews()
        pages.forEachIndexed { i, _ ->
            val b = Button(this).apply {
                text = "Sekme ${i + 1}"
                textSize = 11f
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(if (i == current) accent else panel)
                setOnClickListener { switchTab(i) }
                setOnLongClickListener {
                    if (pages.size > 1) closeTab(i)
                    true
                }
            }
            tabBar.addView(b, LinearLayout.LayoutParams(0, 42, 1f))
        }
    }

    private fun switchTab(index: Int) {
        if (index !in pages.indices) return
        current = index
        pages.forEachIndexed { i, w -> w.visibility = if (i == current) View.VISIBLE else View.GONE }
        address.setText(pages[current].url ?: "")
        refreshTabs()
    }

    private fun closeTab(index: Int) {
        val old = pages.removeAt(index)
        webHolder.removeView(old)
        old.destroy()
        current = (current.coerceAtMost(pages.lastIndex)).coerceAtLeast(0)
        if (pages.isEmpty()) addTab("https://duckduckgo.com") else switchTab(current)
        refreshTabs()
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val url = when {
            input.startsWith("https://") || input.startsWith("http://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(input)
        }
        if (pages.isEmpty()) addTab(url) else pages[current].loadUrl(url)
        showingAI = false
        aiPanel.visibility = View.GONE
    }

    private fun toggleAI() {
        showingAI = !showingAI
        aiPanel.visibility = if (showingAI) View.VISIBLE else View.GONE
        webHolder.visibility = if (showingAI) View.GONE else View.VISIBLE
    }

    private fun showTabs() {
        val names = pages.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "Yeni sekme"}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Açık sekmeler")
            .setItems(names) { _, which -> switchTab(which) }
            .setNegativeButton("Kapat", null).show()
    }

    override fun onBackPressed() {
        if (showingAI) { toggleAI(); return }
        if (pages.isNotEmpty() && pages[current].canGoBack()) pages[current].goBack()
        else if (pages.size > 1) closeTab(current)
        else super.onBackPressed()
    }

    override fun onDestroy() {
        pages.forEach { it.destroy() }
        super.onDestroy()
    }
}
