# VORTEX Browser — Android Studio project

## Open and build
1. Extract this ZIP.
2. Open the `VORTEX_Browser_Android_Studio` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Included in this starter
- Android WebView browser
- DuckDuckGo search from the address bar
- Multiple in-app tabs (tap to switch; long-press a tab to close)
- Back/forward navigation
- VORTEX AI screen placeholder

## Important AI limitation
This project does **not** yet contain a generative AI model. The AI screen explicitly says so rather than pretending to answer with a real model. For a genuinely API-free assistant, a compatible on-device model (for example a GGUF model) and an Android inference runtime/native integration must be added. The model file is not included in this ZIP.
